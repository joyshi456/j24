"use strict";

const IMG_URL = "imgs/";

(function () {

    async function init() {
        
        populateCart();

    }

    async function populateCart() {

        let cartItems = JSON.parse(window.localStorage.getItem("cart"));


        let total = parseFloat(window.localStorage.getItem("cost"));
        let totalText = id("total-box");
        totalText.textContent = "total: \n" + total + "\n\n" + "pay now";

        for(let item of cartItems) {

            let film = gen("div");
            film.classList.add("film-purchase");
            let filmImg = gen("img");
            let filmInfoBox = gen("div");
            let filmInfo = gen("p");

            filmImg.src = item.image;
            filmImg.alt = item.name;

            filmInfo.textContent = item.name + "\n" + item.price;

            filmInfoBox.appendChild(filmInfo);

            let removeFilm = gen("p");
            removeFilm.innerHTML = "&#10005";

            removeFilm.addEventListener("click", async () => {

                //let total = parseFloat(window.sessionStorage.getItem("cost"));
                total = (total - parseFloat(item.price)).toFixed(2);
                let totalText = id("total-box");
                totalText.textContent = "total: \n" + total + "\n\n" + "pay now";
                id("cart-container").removeChild(film);
                //window.sessionStorage.setItem("cost", newTotal);
                

            })

            film.appendChild(filmImg);
            film.appendChild(filmInfoBox);
            film.appendChild(removeFilm);

            id("cart-container").appendChild(film);
            
            

        }
    }




    


    init();
})();