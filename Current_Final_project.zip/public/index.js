"use strict";

const DEBUG = true;
const BASE_URL = "http://localhost:8000";
const CART_URL = "/cart.html";
const ADD_ITEM_EP = "/addFilm";
const REVIEW_URL = "/reviews";
const QUESTIONS_URL = "questions";
const ADD_REVIEW = "/addReview";
const IMG_URL = "imgs/";
const JPG_LENGTH = 4;


(function () {
    async function init() {
        
        populateStrip();
        id("contact").addEventListener("click", contactForm);
        id("search").addEventListener("click", searchFilter);
        let cart = [];
        window.localStorage.setItem("cart", JSON.stringify(cart));
        window.localStorage.setItem("cost", 0);
        id("cart").href = BASE_URL + CART_URL;

    }

    async function populateStrip() {

        let resp = await fetch("/strip");
        let data = await resp.json();
        let films = data.films;
        let countries = [];

        id("films").innerHTML = "";
        id("search").addEventListener("click", searchBar);
        
        for (let i = 0; i < films.length; i++) {
            let poster = gen("img");
            let curFilm = films[i];
            poster.classList.add("poster");
            poster.src = curFilm.image;
            poster.alt = curFilm.name;
            poster.id = formatDirFromTitle(curFilm.name);

            if(countries.indexOf(curFilm.country) == -1) {
                let opt = gen("option");
                countries.push(curFilm.country);
                opt.textContent = curFilm.country;

                id("search-bar").appendChild(opt);
            }


            poster.addEventListener("click", async () => {
                id("film-info").innerHTML = "";
                let infoTitle = gen("h2");
                infoTitle.textContent = curFilm.name + " (" + curFilm.year + ")";

                //add film information labels
                let infoLabels = gen("div");
                infoLabels.id = "info-labels";
                let infoBox = gen("div");
                infoBox.id = "info-box";
                const CONTENTS = ["description", "director", "cast"];
                for(const INFO of CONTENTS) {
                    let infoLabel = gen("a");
                    infoLabel.textContent = INFO;
                    infoLabel.classList.add("info-label");

                    infoLabel.addEventListener("click", async() => {
                        infoBox.innerHTML = "";
                        let infoToAdd = gen("p");
                        infoToAdd.classList.add("film-info-text");
                        infoToAdd.textContent = curFilm[INFO];
                        infoBox.appendChild(infoToAdd);
                    })
                    infoLabels.appendChild(infoLabel);
                }

                //reviews and ratings label, including adding reviews
                let reviewLabel = gen("a");
                reviewLabel.textContent = "reviews";
                reviewLabel.classList.add("info-label");
                let filmDir = formatDirFromTitle(curFilm.name);

                reviewLabel.addEventListener("click", async() => {
                    try {
                        let resp = await fetch("/"+ filmDir + REVIEW_URL);
                        resp = checkStatus(resp);
                        let data = await resp.json();
                        infoBox.innerHTML = "";
                        let rtgs = data.ratings;
                        let rvs = data.reviews;
                        let ratingBox = gen("div");

                        console.log(rtgs);
                        console.log(rvs);

                        let ratingNum = gen("p");
                        ratingNum.textContent = ratingAvg(rtgs);
                        let addARating = gen("p");
                        addARating.textContent = "Add a review!";

                        addARating.addEventListener("click", async () => {
                            id("review-input").classList.remove("hidden"); })
                        id("add-rvw").addEventListener("click", async () => {
                            let params = new FormData(id("review-form"));
                            try {
                            let resp = await fetch("/" + filmDir + ADD_REVIEW, { method : "POST", body : params });
                            resp = checkStatus(resp);
                            let data = await resp.text();
                            let submissionText = gen("p");
                            id("review-input").appendChild(submissionText);
                        
                            } catch (err) {
                            handleError("An error occurred when submitting new review request. " +
                                        "Please try again or email us!");
                            }
                        
                        })

                        ratingBox.appendChild(ratingNum);
                        ratingBox.appendChild(addARating);
                        infoBox.appendChild(ratingBox);
                        
                        console.log(rvs.length);

                        for(let i = 0; i < rvs.length; i++) {
                            let rtgsInfoToAdd = gen("p");
                            let rvsInfoToAdd = gen("p");

                            rtgsInfoToAdd.innerHTML = returnStars(parseInt(rtgs[i]));
                            rvsInfoToAdd.textContent = rvs[i];
                            
                            infoBox.appendChild(rtgsInfoToAdd);
                            infoBox.appendChild(rvsInfoToAdd);
                        }

                    
                    } catch (err) {
                        handleError("An error occurred when submitting new review request. " +
                                    "Please try again or email us!");
                    }

                })
                infoLabels.appendChild(reviewLabel);

                //add "add to cart" label
                let cartLabel = gen("a");
                cartLabel.textContent = "add to cart (" + curFilm["price"] + ")";
                cartLabel.classList.add("info-label");
                cartLabel.addEventListener("click", async() => {
                    infoBox.innerHTML = "";
                    let infoToAdd = gen("p");
                    infoToAdd.classList.add("film-info-text");
                    if(curFilm.quantity > 0) {
                        let cart = JSON.parse(window.localStorage.getItem("cart"));
                        let cost = parseFloat(window.localStorage.getItem("cost"));
                        cart.push(curFilm);
                        cost += parseFloat(curFilm.price);
                        console.log(cost);
                        id("cart-count").textContent = cart.length;
                        window.localStorage.setItem("cart", JSON.stringify(cart));
                        window.localStorage.setItem("cost", cost);
                        curFilm.quantity -=1;
                        infoToAdd.textContent = "Added to cart!";
                        infoBox.appendChild(infoToAdd);
                    }
                    else {
                        infoBox.innerHTML = "";
                        infoToAdd.textContent = "Sorry, this item is sold out :(";
                        infoBox.appendChild(infoToAdd);
                    }
                        
                })
                infoLabels.appendChild(cartLabel);
                
                id("film-info").appendChild(infoTitle);
                id("film-info").appendChild(infoLabels);
                id("film-info").appendChild(infoBox);

            })

            id("films").appendChild(poster);

        }

        id("search-bar").addEventListener("change", async () => {
            //unhide all
            for(let i = 0; i < films.length; i++){ 
                let fName = formatDirFromTitle(films[i].name);
                id(fName).classList.remove("hidden");
            }

            if (id("search-bar").value) {
                for(let f = 0; f < films.length; f++){
                    let cur = films[f];
                    let curName = formatDirFromTitle(cur.name);
                    if (cur.country != this.value) {
                        id(curName).classList.add("hidden");
                    }
                }
            }
        })

    }

    async function searchBar() {
        id("search-bar").classList.remove("hidden");

    }


    /**
 * Adds a new item to the <category>-proposals.json file to be approved later.
 * If no <category>-proposals.json yet exists, will add a new file.
 * Required POST parameters: name, category, description.
 * Optional POST parameter: image - defaults to food.png otherwise.
 * Response type: text/plain
 * Sends a 400 error if missing one of the 3 required params.
 * Sends a 500 error if something goes wrong in file-processing.
 * Sends a success message otherwise.
 */
    async function submitReview() {
        let params = new FormData(id("review-form"));
        try {
          let resp = await fetch(ADD_REVIEW, { method : "POST", body : params });
          resp = checkStatus(resp);
          let data = await resp.text();
            

        } catch (err) {
          handleError("An error occurred when submitting new review request. " +
                      "Please try again or email us!");
        }
    }


    //returns the average rating
  function ratingAvg(ratingData) {
    //Index where ratings start
    let sum = 0;
    let l = ratingData.length;
    for(let i = 0; i < l - 1; i++) {
      sum += parseInt(ratingData[i]);
    }

    return (sum/(l-1)).toFixed(1);
    

  }

  //Gets stars with their HTML entities, so it can be directly added to the innerHTML of the text.
  function returnStars(numStars) {
    const MAX_STARS = 5;
    let stars = "";
    for(let i = 0; i < numStars; i++) {
      stars += "&starf;";
    }
    for(let i = numStars; i < MAX_STARS; i++) {
      stars += "&star;";
    }
    return stars;
  }

    async function displayFilmInfo() {
        let filmDir = extractDir(this.src);
        console.log(this.src);
    }

    async function contactForm() {
        id("film-info").innerHTML = "";
        id("contact-us").classList.remove("hidden");
        let params = new FormData(id("contact-form"));
            try {
            let resp = await fetch("/" + QUESTIONS_URL, { method : "POST", body : params });
            resp = checkStatus(resp);
            let data = await resp.text();
            let submissionText = gen("p");
            id("contact-us").appendChild(submissionText);
        
            } catch (err) {
            handleError("An error occurred when submitting new review request. " +
                        "Please try again or email us!");
            }
                        
    }

    function extractDir(imgDir) {
        let titleLen = imgDir.length;
        return imgDir.substring(IMG_URL.length, titleLen - JPG_LENGTH);
    }
    


    //Takes in the directory name and returns formatted movie title
    function formatFilmTitleFromDir(dirName) {
        let names = dirName.split("-");
        let title = capitalize(names[0]);
        for(let i = 1; i < names.length; i++) {
            title += " " + capitalize(names[i]);
        }
        return title;
    }

    function formatDirFromTitle(title) {
        let names = title.split(" ");
        let dir = uncapitalize(names[0]);
        for(let i = 1; i < names.length; i++) {
            dir += "-" + uncapitalize(names[i]);
        }
        return dir;
    }

    //Capitalizes an inputted word, typically for a title
    function capitalize(word) {
        return word.charAt(0).toUpperCase() + word.slice(1);
    }

    //Removes the capitalization for an inputted word, typically for a directory
    function uncapitalize(word) {
        return word.charAt(0).toLowerCase() + word.slice(1);
    }

    
    init();
})();