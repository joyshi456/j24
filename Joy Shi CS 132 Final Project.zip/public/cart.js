/*
    Name: Joy Shi
    CS 132 Spring 2022
    Date: May 10th, 2022

    This is my cart JS for my E-Commerce store, tasked with updating the cart for my site.
*/
"use strict";

const IMG_URL = "imgs/";

(function () {
  async function init() {
    populateCart();
  }

  async function populateCart() {
    let cartItems = JSON.parse(window.localStorage.getItem("cart"));
    id("cart-count").textContent = cartItems.length;

    let total = parseFloat(window.localStorage.getItem("cost"));
    let totalText = id("total-box");
    totalText.textContent = "total: \n" + total + "\n\n" + "pay now";

    for (let item of cartItems) {
      let film = gen("div");
      film.classList.add("film-purchase");
      let filmImg = gen("img");
      let filmInfoBox = gen("div");
      let filmInfo = gen("p");

      filmImg.src = item.image;
      filmImg.alt = item.name;

      filmInfo.textContent = item.name + "\n" + item.price;

      filmInfoBox.appendChild(filmInfo);

      let removeFilm = gen("p");
      removeFilm.innerHTML = "&#10005";

      removeFilm.addEventListener("click", async () => {
        total = (total - parseFloat(item.price)).toFixed(2);
        let totalText = id("total-box");
        totalText.textContent = "total: \n" + total + "\n\n" + "pay now";
        id("cart-container").removeChild(film);
        const index = cartItems.indexOf(item);
        if (index > -1) {
          cartItems.splice(index, 1);
        }
        id("cart-count").textContent = cartItems.length;
        window.localStorage.setItem("cart", cartItems);
      });

      film.appendChild(filmImg);
      film.appendChild(filmInfoBox);
      film.appendChild(removeFilm);

      id("cart-container").appendChild(film);
    }
  }

  init();
})();
